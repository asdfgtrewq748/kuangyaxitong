# Research Evidence Bundle

exported_at: 2026-02-12T15:43:12.932Z
dataset_id: research_demo
dataset_version: cc09630e88f352cc
split_id: split_20260212_154246_8609a3
primary_exp_id: exp_20260212_154247_0f1a32

包含内容:
- manifests/dataset_manifest.json
- manifests/dataset_quality_report.json
- manifests/split_manifest.json
- results/latest_result.json
- results/suite_result.json
- methods/methods.md
- comparison/*.json|csv
- figures/*.svg
- artifacts/index.json (和可下载产物)