# Research Evidence Bundle

exported_at: 2026-02-12T14:28:00.487Z
dataset_id: research_demo
dataset_version: cc09630e88f352cc
split_id: split_20260212_142721_77e293
primary_exp_id: exp_20260212_142722_92453c

包含内容:
- manifests/dataset_manifest.json
- manifests/dataset_quality_report.json
- manifests/split_manifest.json
- results/latest_result.json
- results/suite_result.json
- methods/methods.md
- comparison/*.json|csv
- figures/*.svg
- artifacts/index.json (和可下载产物)