# Research Evidence Bundle

exported_at: 2026-02-13T13:23:47.118Z
dataset_id: research_demo
dataset_version: cc09630e88f352cc
split_id: split_20260213_132305_71d713
primary_exp_id: exp_20260213_132306_531136

包含内容:
- manifests/dataset_manifest.json
- manifests/dataset_quality_report.json
- manifests/split_manifest.json
- results/latest_result.json
- results/suite_result.json
- methods/methods.md
- comparison/*.json|csv
- figures/*.svg
- artifacts/index.json (和可下载产物)