# Research Evidence Bundle

exported_at: 2026-02-12T13:00:02.182Z
dataset_id: -
dataset_version: -
split_id: split_20260212_125925_e351c3
primary_exp_id: exp_20260212_125925_0341ba

包含内容:
- manifests/dataset_manifest.json
- manifests/dataset_quality_report.json
- manifests/split_manifest.json
- results/latest_result.json
- results/suite_result.json
- methods/methods.md
- comparison/*.json|csv
- figures/*.svg
- artifacts/index.json (和可下载产物)