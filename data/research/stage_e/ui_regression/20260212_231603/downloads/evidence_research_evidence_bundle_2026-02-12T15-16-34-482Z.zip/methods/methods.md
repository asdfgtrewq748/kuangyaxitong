# Methods Summary

## Data Governance
- Dataset ID: research_demo
- Dataset Version: cc09630e88f352cc
- Dataset Rows: 120
- Label Column: label
- Positive Values: 1

## Split Strategy
- Split ID: split_20260212_151604_935d9b
- Strategy: -
- Ratios: train=-, val=-, test=-
- Leakage Overlap: train-val=-, train-test=-, val-test=-

## Experiment Protocol
- Primary Experiment ID: exp_20260212_151604_c5cffa
- Model Type: geomodel_aware
- Seed: 42
- Metrics: auc, pr_auc, f1, brier, mae, rmse, paired_significance_p
- Statistics: bootstrap 95% CI and paired significance (as implemented by backend experiment runner).

## Comparison Snapshot
- Compared Experiments: 2
- Visualized Metric: auc
- Model Groups: 2
- Champion Count: 7

## Notes
- This material is generated from current reproducibility workspace state.
- Use this file as supplementary methods draft for manuscript preparation.